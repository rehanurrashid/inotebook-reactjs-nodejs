// middlewares/authenticate.js
const jwt = require('jsonwebtoken');

// JWT Secret - should be stored in environment variables
const JWT_SECRET = process.env.JWT_SECRET || 'yourSecretKey'; // Default value for local testing

const authenticate = (req, res, next) => {
    // Get token from Authorization header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
        return res.status(401).json({ error: "No token provided, access denied." });
    }

    try {
        // Verify the token and decode its contents
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Attach the user ID to the request object
        req.userId = decoded.userId;
        
        // Proceed to the next middleware or route handler
        next();
    } catch (err) {
        return res.status(401).json({ error: "Invalid or expired token, access denied." });
    }
};

module.exports = authenticate;
