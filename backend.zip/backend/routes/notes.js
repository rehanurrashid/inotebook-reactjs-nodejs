// routes/notes.js
const express = require('express');
const router = express.Router();
const authenticate = require('../middlewares/authenticate'); // Authentication middleware
const Notes = require('../models/Notes'); // Notes model

// Create a new note
router.post('/', authenticate, async (req, res) => {
    const { title, description, tag } = req.body;
    
    try {
        // Create a new note with the userId from the authenticated user
        const newNote = new Notes({
            title,
            description,
            tag,
            userId: req.userId  // Set the userId from the authenticated user
        });

        await newNote.save();
        res.status(201).json(newNote);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to create the note." });
    }
});

// Fetch all notes for the logged-in user
router.get('/', authenticate, async (req, res) => {
    try {
        // Find notes by the logged-in user (userId from the token)
        const notes = await Notes.find({ userId: req.userId });
        res.status(200).json(notes);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to fetch notes." });
    }
});

// Update an existing note
router.put('/:id', authenticate, async (req, res) => {
    const { title, description, tag } = req.body;
    
    try {
        // Find the note by ID and ensure it's associated with the authenticated user
        let note = await Notes.findOne({ _id: req.params.id, userId: req.userId });

        if (!note) {
            return res.status(404).json({ error: "Note not found or not authorized." });
        }

        // Update the note's details
        note.title = title || note.title;
        note.description = description || note.description;
        note.tag = tag || note.tag;

        await note.save();
        res.status(200).json(note);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to update the note." });
    }
});

// Delete a note
router.delete('/:id', authenticate, async (req, res) => {
    try {
        // Find the note by ID and ensure it's associated with the authenticated user
        const note = await Notes.findOneAndDelete({ _id: req.params.id, userId: req.userId });

        if (!note) {
            return res.status(404).json({ error: "Note not found or not authorized." });
        }

        res.status(200).json({ message: "Note deleted successfully." });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to delete the note." });
    }
});

module.exports = router;
