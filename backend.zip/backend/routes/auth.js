const express = require('express');
const router = express.Router();
const User = require('../models/Users');
const { body , validationResult } = require('express-validator');
var bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const authenticate = require('../middlewares/authenticate');

router.post('/createUser', [
    body('email').isEmail().withMessage('Please provide a valid email'),
    body('password').isLength({ min: 5 }).withMessage('Password must be at least 5 characters'),
    body('name').isLength({ min: 5 }).withMessage('Name must be at least 5 characters'),
], async (req, res) => {
    // Check for validation errors
    const result = validationResult(req);
    if (!result.isEmpty()) {
        return res.status(400).json({ errors: result.array() });
    }

    try {
        // Check if user already exists
        let user = await User.findOne({ email: req.body.email });
        if (user) {
            return res.status(400).json({ error: "User already exists." });
        }

        const salt = await bcrypt.genSalt(10);
        secPass = await bcrypt.hash(req.body.password, salt);

        // Create new user
        user = await User.create({
            name: req.body.name,
            email: req.body.email,
            password: secPass, // You may want to hash the password before saving it
        });

        // Return the created user (minus sensitive information like password)
        res.status(201).json({
            id: user._id,
            name: user.name,
            email: user.email,
            password: secPass
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "An error occurred while creating the user." });
    }
});

const JWT_SECRET = process.env.JWT_SECRET || 'yourSecretKey'; // Should be in environment variables

// login
router.post('/login', [
    body('email').isEmail().withMessage('Please provide a valid email'),
    body('password', 'Password cannot be blank').exists(),
], async (req, res) => {
    // Check for validation errors
    const result = validationResult(req);
    if (!result.isEmpty()) {
        return res.status(400).json({ errors: result.array() });
    }

    const { email, password } = req.body;

    try {
        // Find the user in the database
        let user = await User.findOne({ email: email });
        
        if (!user) {
            return res.status(400).json({ error: "Invalid credentials." });
        }

        // Compare the provided password with the stored hashed password
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(400).json({ error: "Invalid credentials." });
        }

        // If credentials are correct, generate a JWT token
        const token = jwt.sign(
            { userId: user._id },
            JWT_SECRET,
            { expiresIn: '1h' } // Token expires in 1 hour
        );

        // Return the token and user information (excluding password)
        res.json({
            message: "Login successful",
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "An error occurred during login." });
    }
});


// Route to get user details, protected by the authentication middleware
router.get('/me', authenticate, async (req, res) => {
    try {
        // Fetch user details from the database using the userId from the token
        const user = await User.findById(req.userId);
        
        if (!user) {
            return res.status(404).json({ error: "User not found." });
        }

        // Return the user details, excluding sensitive information like password
        res.json({
            id: user._id,
            name: user.name,
            email: user.email
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "An error occurred while fetching user details." });
    }
});

module.exports = router;