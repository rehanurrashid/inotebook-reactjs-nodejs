const connectToMongo = require('./db');

connectToMongo();

const express = require('express')
const cors = require('cors');
const app = express()
const port = 4000

app.use(cors({
  origin: 'http://localhost:4001',  // Allow requests from the frontend's origin
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // Allow specific HTTP methods
  allowedHeaders: ['Content-Type', 'Authorization'], // Specify allowed headers
}));

app.use(express.json());

app.use('/api/auth', require('./routes/auth'))
app.use('/api/notes', require('./routes/notes'))

app.listen(port, () => {
  console.log(`iNotebook listening on port ${port}`)
})